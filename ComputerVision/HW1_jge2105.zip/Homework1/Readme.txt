Homework #1 for Computer Vision
Colmbia University -- Spring 2013 
Created by Joe Ellis

Readme:
Please cd into the working directory 'Homework1' to run all scripts.
Problems 4 and 5 were turned in to the TAs by hand.  
Please email jge2105@columbia.edu if an electronic copy of these problems are needed.